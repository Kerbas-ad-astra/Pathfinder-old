Buffalo MSEV - Explore Space In Style

The NASA Multimission Modular Space Exploration Vehicle (MMSEV) Is a radical new concept that uses common components for ground rovers and in-space exploration craft. This modularity opens up the possibility of a variety of different configurations. The Buffalo Modular Space Exploration Vehicle (MSEV) is the KSP equivalent from Wild Blue Industries. With the Buffalo, you can explore space in style!

Features
- Modular design lets you build rovers, aircraft, and spacecraft.
- Fits inside the standard 3.75m cargo bay.
- KIS/KAS friendly; you can assemble and disassemble the Buffalo out in the field.
- Crew spaces have IVAs with support for stock as well as ASET Props/ASET Avionics.
- Designs inspired by real-world NASA MMSEV with family resemblance to ground vehicles around KSC.

References
NASA MMSEV: http://www.nasa.gov/exploration/technology/space_exploration_vehicle/

Recommended Mods (you'll need RPM as well as ASET Props and ASET Avionics to use the Buffalo Command Cab's ASET IVA)
Raster Prop Monitor: https://kerbalstuff.com/mod/425/Raster%20Prop%20Monitor
ASET Props: https://kerbalstuff.com/mod/1021/ASET%20Props
ASET Avionics: https://kerbalstuff.com/mod/1023/ASET%20Avionics

Note: The current parts list lets you create a rover, but future updates will expand the parts list for more options.

---INSTALLATION---

Copy the contents of the mod's GameData directory into your GameData folder. Specifically you'll need:

CommunityResourcePack
WildBlueIndustries/000WildBlueTools
WildBlueIndustries/Buffalo
ModuleManager.dll (the latest version is included)

If these directories already exist, then delete the existing ones before installing the latest update.

---REVISION HISTORY---

0.1.2

This release fixes a number of issues that resulted from separating the Buffalo out of Pathfinder. It also introduces two new Buckboard storage containers, and a couple of new parts for the Buffalo. Finally, the Buffalo Crew Cabin and Buffalo Command Cab have been improved.

New Parts
- Added MC-2000 Buckboard and MC-3000 Buckboard. With colliders and glowing resource decals. ;)
- Added the Auxiliary Electronic Navigator (AuxEN). In the Old West, oxen were frequently used to pull wagons. The AuxEN doesn't pull anything, but it does the driving. The probe core is the same size as a Chassis 1u, and supports RemoteTech, AntennaRange, and kOS.
- Added an adapter that tapers from the Buffalo cab form factor to a 1.25m cylinder. 

Buffalo Command cab
- Widened the headlight beams and angled them down slightly for better ground operations.
- You can now toggle the headlights separately from the cabin lights. Both cabin lights and headlights will turn on when you tap on the Lights button.

Buffalo Crew Cab
- Reworked the crew cab to include doors and ladders on its sides.
- Added a small amount of inventory space.

Bug Fixes
- The Buckboard MC-1000's decal glows again.
- Fixed file paths for several Buffalo parts so they'll show up again.
- Moved Trailer Hitch to Utility.
- Moved Chassis Decoupler to Structural.

0.1.1

Bug Fixes
- Fixed a collider issue with the Buckboard.
- Kerbals will now orient properly when going on EVA from the crew cabin.
- Made it easier to enter the crew cabin when climbing up the trailer hitch.
- The Chassis Decoupler will now show up properly in the parts catalog.
- The KAS Pipe ID labels now glow properly.

0.1.0 Where The Buffalo Roam

- Initial release

---ACKNOWLEDGEMENTS

Module Manager by ialdabaot
Community Resource Pack by RoverDude, Nertea, and the KSP community
Portions of this codebase include source by Snjo and Swamp-IG, used under CC BY-NC SA 4.0 license
Icons by icons8: https://icons8.com/license/
Eve: Order Zero graphic courtesy of Kuzztler and used with permission.

---LICENSE---

Source code copyrighgt 2015, by Michael Billard (Angel-125)
License: CC BY-NC-SA 4.0
License URL: https://creativecommons.org/licenses/by-nc-sa/4.0/
Wild Blue Industries is trademarked by Michael Billard and may be used for non-commercial purposes. All other rights reserved.
Note that Wild Blue Industries is a ficticious entity 
created for entertainment purposes. It is in no way meant to represent a real entity.
Any similarity to a real entity is purely coincidental.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.